CREATE proc [dbo].[USP_checkLogin]
@userName nvarchar(150), @password nvarchar(250)
as
begin
	declare @hashcode nvarchar(250)
	select @hashcode = hashbytes('sha2_512', @password)
	select COUNT(*) from dbo.account as act where act.user_name = @userName and act.password = @hashcode
end
go

