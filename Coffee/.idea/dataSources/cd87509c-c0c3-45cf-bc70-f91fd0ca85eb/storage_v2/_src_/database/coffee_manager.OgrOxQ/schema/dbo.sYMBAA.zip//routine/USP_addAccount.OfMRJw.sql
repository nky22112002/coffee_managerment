CREATE proc [dbo].[USP_addAccount]
@displayName nvarchar(100), @userName nvarchar(100),@typeAccount int
as 
begin
	declare @isExist int = null
	select @isExist = count(*) from account where user_name = @userName
	declare @defaultPassword nvarchar(250)
	declare @password nvarchar(250) = '1'
	select @defaultPassword = hashbytes('sha2_512', @password)
	if(@isExist = 0)
		begin
			insert account
			(display_name, user_name, password,type_account)
			values
			(@displayName, @userName, @defaultPassword, @typeAccount)
		end

end
go

