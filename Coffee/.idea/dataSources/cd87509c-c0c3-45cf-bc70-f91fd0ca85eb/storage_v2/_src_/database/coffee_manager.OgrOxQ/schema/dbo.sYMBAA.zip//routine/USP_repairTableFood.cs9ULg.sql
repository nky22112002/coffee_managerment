CREATE proc [dbo].[USP_repairTableFood]
@id int, @tablefoodName nvarchar (100), @status nvarchar(100)
as
begin
	declare @isExistTableFood int
	select @isExistTableFood = count(*) from table_food where name = @tablefoodName and id = @id
	if(@isExistTableFood = 1)
		update table_food set name = @tablefoodName, status = @status where id = @id
end
go

