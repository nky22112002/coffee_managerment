create proc [dbo].[USP_addTableFood]
@tablefoodName nvarchar(100)
as
begin
	declare @id int
	select @id = MAX(id) + 1 from table_food
	declare @isExistTableFood int
	select @isExistTableFood = count(*) from table_food where name = @tablefoodName 
	if(@isExistTableFood = 0)
		begin
		SET IDENTITY_INSERT dbo.table_food ON
			insert table_food
			(id , name)
			values
			(@id ,@tablefoodName)
			SET IDENTITY_INSERT dbo.table_food ON
		end

end
go

