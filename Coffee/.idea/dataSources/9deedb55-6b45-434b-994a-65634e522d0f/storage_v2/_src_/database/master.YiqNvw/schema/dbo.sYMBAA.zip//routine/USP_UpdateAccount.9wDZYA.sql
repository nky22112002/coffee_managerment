CREATE proc [dbo].[USP_UpdateAccount]
@userName nvarchar(100), @password nvarchar(150), @newPassword nvarchar (150)
as
begin
		declare @isRightPass int = 0
		declare @hashPassword nvarchar(150)
		select @hashPassword = HASHBYTES('sha2_512', @password)
		declare @hashNewPassword nvarchar(150)
		select @hashNewPassword = HASHBYTES('sha2_512', @newPassword)
		select @isRightPass = count(*) from account where user_name = @userName and Password = @hashPassword
		if(@isRightPass = 1)
			begin
				if(@newPassword != null or @newPassword != '')
					update account set Password = @hashNewPassword where user_name = @userName
			end
		
end
go

