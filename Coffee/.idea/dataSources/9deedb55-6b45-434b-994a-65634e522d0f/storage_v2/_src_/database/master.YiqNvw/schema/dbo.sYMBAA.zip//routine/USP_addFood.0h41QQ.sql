create proc [dbo].[USP_addFood]
@foodName nvarchar(100), @idCategory int, @price int
as 
begin
	declare @isExist int = null
	select @isExist = count(*) from food where name = @foodName
	declare  @idFood int = 0
	select @idFood = max(id)+1 from food
	SET IDENTITY_INSERT dbo.food ON
	if(@isExist = 0)
		begin
			insert food
			(id, name, id_category, price)
			values
			(@idFood, @foodName, @idCategory, @price)
		end
	SET IDENTITY_INSERT dbo.food OFF

end
go

