create proc [dbo].[USP_addCategory]
@categoryName nvarchar(100)
as 
begin
	declare @isExist int = null
	select @isExist = count(*) from food_category where category_name = @categoryName
	declare @idCategory int = 0
	select @idCategory = max(id)+1 from food_category
	SET IDENTITY_INSERT dbo.food_category ON
	if(@isExist = 0)
		begin
			insert food_category
			(id, category_name)
			values
			(@idCategory ,@categoryName)
		end
	SET IDENTITY_INSERT food_category OFF


end
go

