create trigger [dbo].[UTG_UpdateBill]
on bill for update
as 
begin
	declare @idBill int
	select @idBill = id from inserted
	declare @idTable int
	select @idTable = id_table from bill where id = @idBill
	declare @count int 
	select @count = count(*) from bill where id_table = @idTable and status = 0
	if(@count = 0)
	begin
		update table_food set status = N'Empty' where id = @idTable
	end
end
go

