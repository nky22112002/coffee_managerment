create proc [dbo].[USP_InsertBillInfo]
@idBill int, @idFood int, @count int
as
begin
	declare @isExitsBillInfo int
	declare @foodCount int = 1

	select @isExitsBillInfo = id, @foodCount = b.count
	from bill_info as b
	where id_bill = @idBill and id_food = @idFood
	if(@isExitsBillInfo > 0)
	begin
		declare @newCount int = @foodCount + @count
		if(@newCount > 0)
			update bill_info set count = @foodCount + @count where id_food = @idFood
		else
			begin
				delete bill_info where id_bill = @idBill and id_food = @idFood
				declare @tableID int
				select @tableID = id_table from bill where id = @idBill and status = 0
				declare @temp int 
				select @temp = count(*) from bill_info where id_bill = @idBill
				if(@temp = 0)
					update table_food set status = N'Empty' where id = @tableID
				
			end
	end
	
	else
	begin
	declare @c int = @count
		if(@c > 0)
			insert bill_info
			(id_bill, id_food, count)
			values(@idBill,
				@idFood,
				@count)
	end
end
go

