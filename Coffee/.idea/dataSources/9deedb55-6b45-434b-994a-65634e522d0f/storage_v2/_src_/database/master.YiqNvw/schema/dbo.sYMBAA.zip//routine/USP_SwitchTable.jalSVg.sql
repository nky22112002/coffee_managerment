
create proc [dbo].[USP_SwitchTable]
@idTable1 int, @idTable2 int
as
begin
	declare @idFirstBill int
	declare @idSecondBill int

	declare @isFirstTablEmpty int = 1
	declare @isSecondTablEmpty int = 1

	select @idSecondBill = id from bill where id_table = @idTable2 and status = 0
	select @idFirstBill = id from bill where id_table = @idTable1 and status = 0

	if(@idFirstBill is null)
		begin
			insert bill
				(date_check_in,
				date_check_out,
				id_table,
				status)
			values
				(getdate(),
				null,
				@idTable1,
				0)
			select @idFirstBill = max(id) from bill where id_table = @idTable1 and status = 0
		end
	select @isFirstTablEmpty = count(*) from bill_info where id_bill = @idFirstBill
	if(@idSecondBill is null)
		begin
			insert bill
				(date_check_in,
				date_check_out,
				id_table,
				status)
			values
				(getdate(),
				null,
				@idTable2,
				0)
			select @idSecondBill = max(id) from bill where id_table = @idTable2 and status = 0
		end
	select @isSecondTablEmpty = count(*) from bill_info where id_bill = @idSecondBill
	select id into IDBillInfoTable from bill_info where id_bill = @idSecondBill
	update bill_info set id_bill = @idSecondBill where id_bill = @idFirstBill
	update bill_info set id_bill = @idFirstBill where id in (select * from IDBillInfoTable)
	drop table IDBillInfoTable
	if(@isFirstTablEmpty = 0)
		update table_food set status = N'Empty' where id = @idTable2
	if(@isSecondTablEmpty = 0)
		update table_food set status = N'Empty' where id = @idTable1
end
go

