create trigger [dbo].[UTG_UpdateBillInfo]
on bill_info for insert, update
as 
begin
	declare @idBill int
	select @idBill = id_bill from inserted
	declare @idTable int
	select @idTable = id_table from bill where id = @idBill and status = 0
	declare @count int 
	select @count = count(*) from bill_info where id_bill = @idBill
	if(@count > 0)
	begin
		update table_food set status = N'Active' where id = @idTable
	end
	else
	begin
		update table_food set status = N'Empty' where id = @idTable
	end
end
go

