create proc [dbo].[USP_deleteCategory]
@categoryName nvarchar(100)
as
begin
	declare @idCategory int
	select @idCategory = id from food_category where category_name = @categoryName
	declare @idFood int
	select @idFood = id from food where id_category = @idCategory
	delete from bill_info where id_food = @idFood
	delete from food where id_category = @idCategory
	delete from food_category where category_name = @categoryName
end
go

