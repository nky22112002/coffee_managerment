create proc [dbo].[USP_repairCategory]
@categoryName nvarchar(100) , @id int
as
begin
	declare @isExistCategory int
	select @isExistCategory = count(*) from food_category where category_name = @categoryName
	if(@isExistCategory = 0)
		update food_category set category_name = @categoryName where id = @id
end
go

