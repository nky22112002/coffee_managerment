create proc [dbo].[USP_InsertBill]
@idTable int
as
begin
	insert dbo.bill
	(date_check_in,
	date_check_out,
	id_table,
	status)
	values (getdate(),
			null,
			@idTable,
			0)
end
go

