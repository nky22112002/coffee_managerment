create proc [dbo].[USP_GetListBillByDate]
@pages int, @checkIn date, @checkOut date
as
begin
	declare @pageRows int = 11
	declare @exceptRows int = (@pages - 1) * @pageRows

	;with BillShow as ( select b.id, t.name, b.total_price, b.date_check_in, b.date_check_out, b.discount
	from bill as b, table_food as t
	where b.date_check_in >= @checkIn and date_check_out <= @checkOut and b.status = 1 and t.id = b.id_table)
	select top (@pageRows) * from BillShow where id not in (select top (@exceptRows) id from BillShow)

end
go

