create proc [dbo].[USP_Register]
@displayName nvarchar(100), @userName nvarchar(100), @password nvarchar(150),@typeAccount int
as
begin
	declare @isExist int
	declare @hashPass nvarchar(150)
	select @hashPass = HASHBYTES('sha2_512', @password)
	select @isExist = COUNT(*) from account where user_name = @userName
	if(@isExist = 0)
		begin
			insert account
			(display_name, user_name, password,type_account)
			values
			(@displayName, @userName, @hashPass, @typeAccount)
		end
end
go

